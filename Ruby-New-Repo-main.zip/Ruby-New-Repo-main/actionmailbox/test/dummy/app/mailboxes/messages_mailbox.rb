class MessagesMailbox < ApplicationMailbox
  def process
  end
end
