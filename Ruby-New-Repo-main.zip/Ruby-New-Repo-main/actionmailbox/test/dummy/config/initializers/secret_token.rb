Rails.application.config.secret_key_base = "b3c631c314c0bbca50c1b2843150fe33"
