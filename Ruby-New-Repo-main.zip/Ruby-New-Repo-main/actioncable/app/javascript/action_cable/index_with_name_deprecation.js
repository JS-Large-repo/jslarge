export * from "./index"
console.log("DEPRECATION: action_cable.js has been renamed to actioncable.js – please update your reference before Rails 8")
